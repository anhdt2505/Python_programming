import sys
import random

words_list = ["Moscow", "Tokyo", "Berlin", "London", "Seoul"] 
alphabet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

random_word = random.choice(words_list)
word_to_guess = []

for i in range(len(random_word)):
    word_to_guess.append(random_word[i])
current_word = []

for i in word_to_guess:  
    current_word.append("_")

guess_letters = []
guesses = 0

def hangman_name():
    name = input("Enter name for Hangman: ")
    print("You have to save", name, "from being hang!")

def hangman_graphic(guesses):
    print("")
    print("Currently letters: ", end=" ")
    for i in range(len(current_word)):
        print(current_word[i], end=" ")
    print("")
    print("Letters you have already tried:", end=" ")
    for i in range(len(guess_letters)):
        print(guess_letters[i], end=" ")
    print("")
    if guesses == -1: 
        print("       0      ")
        print("     ~~|~~    ")
        print("      / \     ")
        print("You saved your life !")
        print(" !!! YOU WON !!!")
        print("Wanna play again?")
    elif guesses == 0:
        print("________      ")
        print("|      |      ")
        print("|             ")
        print("|             ")
        print("|             ")
        print("|             ")
    elif guesses == 1:
        print("________       ")
        print("|      |       ")
        print("|      0       ")
        print("|              ")
        print("|              ")
        print("|              ")
        print("---Attempt 1---")
    elif guesses == 2:
        print("________       ")
        print("|      |       ")
        print("|      0       ")
        print("|     /        ")
        print("|              ")
        print("|              ")
        print("---Attempt 2---")
    elif guesses == 3:
        print("________       ")
        print("|      |       ")
        print("|      0       ")
        print("|     /|       ")
        print("|              ")
        print("|              ")
        print("---Attempt 3---")
    elif guesses == 4:
        print("________       ")
        print("|      |       ")
        print("|      0       ")
        print("|     /|\      ")
        print("|              ")
        print("|              ")
        print("---Attempt 4---")
    elif guesses == 5:
        print("________       ")
        print("|      |       ")
        print("|      0       ")
        print("|     /|\      ")
        print("|     /        ")
        print("|              ")
        print("---Attempt 5---")
    else:  
        print("________       ")
        print("|      |       ")
        print("|      0       ")
        print("|     /|\      ")
        print("|     / \      ")
        print("|              ")
        print("The noose tightens around your neck, and you feel the")
        print("sudden urge to urinate.")
        print("                                .....     ")
        print("                               C C  /     ")
        print("                              /<   /      ")
        print("               ___ __________/_#__=o      ")
        print("              /(- /(\_\________   \       ")
        print("              \ ) \ )_      \o     \      ")
        print("              /|\ /|\       |'     |      ")
        print("                            |     _|      ")
        print("                            /o   __\      ")
        print("                           / '     |      ")
        print("                          / /      |      ")
        print("                         /_/\______|      ")
        print("                        (   _(    <       ")
        print("                         \    \    \      ")
        print("                          \    \    |     ")
        print("                           \____\____\    ")
        print("                           ____\_\__\_\   ")
        print("                         /`   /`     o\   ")
        print("                         |___ |_______|   ")
        print("                                          ")
        print("GAME OVER!")

def guess_input():
    global guesses
    while True:
        player_input = input("Please input your guess (a single letter): ")
        if player_input in alphabet:
            if player_input in guess_letters:
                print(">>> You have already tried this letter, hurry up! <<<")
            else:
                guess_letters.append(player_input)
                if player_input in word_to_guess:
                    print("Good job! Keep it up <3")
                    for i in range(len(word_to_guess)):
                        if word_to_guess[i] == player_input:
                            current_word[i] = player_input
                else:
                    print(">>> Oops, there is no such letter in the guessed word! <<<")
                    guesses += 1

        else:
            print(">>> Nah! Please input a single letter in Alphabet! <<<")

        if guesses > 5: 
            hangman_graphic(guesses)
            break
        elif "_" in current_word: 
            hangman_graphic(guesses)
        else: 
            hangman_graphic(-1)
            break


def main():
    hangman_name()
    hangman_graphic(guesses)
    guess_input()


main()