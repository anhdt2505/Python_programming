import webbrowser # Open Web Browser # 

class Video: # Video's info
    def __init__(self, title, link): # Initialize video's info #
        self.title = title
        self.link = link
        self.seen = False

    def open(self):
        webbrowser.open(self.link)
        self.seen = True

class Playlist: # Video management (playlist) #
    def __init__(self, name, description, rating, videos): # Initialize playlist #
        self.name = name
        self.description = description
        self.rating = rating
        self.videos = videos

def select_in_range(prompt, min, max): # Select in a nominated range #
    choice = input(prompt)
    while not choice.isdigit() or int(choice) < min or int(choice) > max:
        choice = input(prompt)
    choice = int(choice)
    return choice

def ask_video_info(): # Add a video #  
    title = input("Please enter video title: ") + "\n"
    link = input("Please enter video link: ") + "\n"
    video = Video(title, link)
    return video

def print_video(video): # Show video's info #  # sort()
    print("Video title: ", video.title, end="")
    print("Video link: ", video.link, end="")

def ask_videos_info(): # Add videos #
    videos = []
    total_video = int(input("Please enter number of videos: "))
    for i in range(total_video):
        print("Fill in video's ", i+1, "information.")
        vid = ask_video_info()
        videos.append(vid)
    return videos

def print_videos(videos): # Show videos's info #
    for i in range(len(videos)):
        print("---Video " + str(i+1) + " information---")
        print_video(videos[i])
        print()

def create_playlist(): # Create a new playlist #                             # Option 1 #
    playlist_name = input("Please enter playlist name: ") + "\n"
    playlist_description = input("Please enter playlist description: ") + "\n"
    playlist_rating = input("Please enter playlist rating (1-5): ") + "\n"
    playlist_videos = ask_videos_info()
    playlist = Playlist(playlist_name, playlist_description, playlist_rating, playlist_videos)
    print("<<< New playlist created Successfully! >>>")
    return playlist

def add_video(playlist): #Add a new video #                                  # Option 2 #
    print("Please enter new video information:")
    new_video_title = input("Please enter new video title: ") + "\n"
    new_video_link =  input("Please enter new video link: ") + "\n"
    new_video = Video(new_video_title, new_video_link)
    playlist.videos.append(new_video)
    print("<<< Added Successfully! >>>")
    return playlist

def show_playlist(playlist): # Show playlist #                               # Option 3 #
    print("Playlist name: " + playlist.name, end="")
    print("Playlist description: " + playlist.description, end="")
    print("Playlist rating: " + playlist.rating, end="")
    print_videos(playlist.videos)

def play_video(playlist): # Play a video #                                   # Option 4 #
    print_videos(playlist.videos)
    total = len(playlist.videos)
    choice = select_in_range("Play a video (1," + str(total) + "): " , 1,total)    
    print("Open video: " + playlist.videos[choice-1].title + " - " + playlist.videos[choice-1].link, end="")
    playlist.videos[choice-1].open()

def remove_video(playlist): # Delete a video #                               # Option 5 #
    print_videos(playlist.videos)
    choice = select_in_range("Please enter the video you want to Delete: ", 1, len(playlist.videos))
    new_video_list = []
    # del playlist.videos[choice-1]
    for i in range(len(playlist.videos)):
        if i == choice-1:
            continue
        new_video_list.append(playlist.videos[i])
    playlist.videos = new_video_list
    print("<<< Removed Successfully! >>>")
    return playlist

def update_playlist(playlist): # Update playlist's information #             # Option 6 #
    print("Which information you would like to change?")
    print("1. Playlist Name.")    
    print("2. Playlist Description.") 
    print("3. Playlist Rating.")  

    choice = select_in_range("Please choose an option you want to Update (1-3):", 1, 3)
    if choice == 1:
        new_playlist_name = input("Enter new Name for playlist: ") + "\n"
        playlist.name = new_playlist_name
        print("<<< Updated Successfully! >>>")
        return playlist
    if choice == 2:
        new_playlist_description = input("Enter new Description for playlist: ") + "\n"
        playlist.description = new_playlist_description
        print("<<< Updated Successfully! >>>")
        return playlist
    if choice == 3:
        new_playlist_rating = str(select_in_range("Enter new Rating (1-5): ",1,5)) + "\n"
        playlist.rating = new_playlist_rating
        print("<<< Updated Successfully! >>>")
        return playlist

def write_video_txt(video, file): # Write a video to a text file #
    file.write(video.title)
    file.write(video.link)

def read_video_from_txt(file): # Read a video from a text file #
    title = file.readline()
    link = file.readline()
    video = Video(title, link)
    return video

def write_videos_txt(videos, file): # Write videos to a text file #  
    total = len(videos)
    file.write(str(total) + "\n")
    for i in range(total):
        write_video_txt(videos[i], file)

def read_videos_from_txt(file): # Read videos from a text file #
    videos = []
    total = file.readline()     
    for i in range(int(total)):
        video = read_video_from_txt(file)
        videos.append(video)
    return videos                        

def read_playlist_from_txt(): # Read playlist from a text file #
    with open("mp3.txt", "r") as file:
        playlist_name = file.readline()
        playlist_description = file.readline()
        playlist_rating = file.readline()
        playlist_videos = read_videos_from_txt(file)
    playlist = Playlist(playlist_name, playlist_description, playlist_rating, playlist_videos)
    return playlist

def save_playlist(playlist): # Save and Exit #                                # Option 7 #
    with open("mp3.txt", "w") as file:
        file.write(playlist.name)
        file.write(playlist.description)
        file.write(playlist.rating)
        write_videos_txt(playlist.videos, file)
    print("<<< Successfully saved playlist to a text file! >>>")

def show_menu():  # Menu #
    print("Playlist Menu:")
    print("-------------------------------------")
    print("| Option 1: Create a new playlist.  |")
    print("| Option 2: Add a video.            |")
    print("| Option 3: Show music playlist.    |")
    print("| Option 4: Play a video.           |")
    print("| Option 5: Remove a video.         |")
    print("| Option 6: Update music playlist.  |")
    print("| Option 7: Save and Exit.          |")
    print("-------------------------------------")

def main(): # Main() #
    try:
        playlist = read_playlist_from_txt()
        print("Loaded data Successfully !!!")
    except:
        print("Welcome to Group 16's project!")     

    while True:
        show_menu()
        choice = select_in_range("Select an option (1-7):", 1, 7)
        if choice == 1: # Create #
            playlist = create_playlist()  
            input("\nPress Enter to continue.\n")   
        elif choice == 2: # Add #
            playlist = add_video(playlist)  
            input("\nPress Enter to continue.\n")   
        elif choice == 3: # Show #
            show_playlist(playlist)     
            input("\nPress Enter to continue.\n")   
        elif choice == 4: # Play #
            play_video(playlist)  
            input("\nPress Enter to continue.\n")
        elif choice == 5: # Remove #
            playlist = remove_video(playlist)       
            input("\nPress Enter to continue.\n")
        elif choice == 6: # Update #
            playlist = update_playlist(playlist)
            input("\nPress Enter to continue.\n")
        elif choice == 7: # Save #
            save_playlist(playlist) 
            input("\nPress Enter to continue.\n")   
            break
        else:
            print("Wrong Input, Exist.")
            break
     

main()