class Employee_info: # Employee's info #     
    def __init__(self, ID, name, age, sex, address, position, salary): # Initialize employee's info #
        self.ID = ID
        self.name = name
        self.age = age 
        self.sex = sex      
        self.address = address
        self.position = position
        self.salary = salary

class Employee_list: # Employee management #
    def __init__(self, title, description, manager, employees): # Initialize employee's list # 
        self.title = title
        self.description = description
        self.manager = manager        
        self.employees = employees 

def select_in_range(prompt, min, max): # Select in a nominated range #                                                    
    choice = input(prompt)
    while not choice.isdigit() or int(choice) < min or int(choice) > max:
        choice = input(prompt)
    choice = int(choice)
    return choice

def ask_employee_info(): # Add an employee #                                                                 
	ID = input("Please enter employee's ID: ") + "\n"
	name = input("Please enter employee's name: ") + "\n"
	age = input("Please enter employee's age: ") + "\n"
	sex = input("Please enter employee's sex: ") + "\n"
	address = input("Please enter employee's address: ") + "\n"
	position = input("Please enter employee's position: ") + "\n"
	salary = input("Please enter employee's salary: ") + "\n"
	employee = Employee_info(ID, name, age, sex, address, position, salary)
	return employee

def print_employee(employee): # Show employee's info #                                                       
    print("Employee's ID: ", employee.ID, end="")
    print("Employee's name: ", employee.name, end="")
    print("Employee's age: ", employee.age, end="")
    print("Employee's sex: ", employee.sex, end="")
    print("Employee's address: ", employee.address, end="")
    print("Employee's position: ", employee.position, end="")
    print("Employee's salary: ", employee.salary, end="")

def ask_employees_info(): # Add employees #                                                               
    employees = []
    total_employee = int(input("Please enter number of employees: "))
    for i in range(total_employee):
        print("Fill in employee's", i+1, "information.")
        emp = ask_employee_info()
        employees.append(emp)
    return employees

def print_employees(employees): # Show employees's info #                                                       
    for i in range(len(employees)):
        print("---Employee's " + str(i+1) + " information---")
        print_employee(employees[i])
        print()

def create_emp_list(): # Create a new employee list #                             # Option 1 #                                                                
    emplist_title = input("Please enter employee's list Title: ") + "\n"
    emplist_description = input("Please enter employee's list Description: ") + "\n"
    emplist_manager = input("Please enter employee's list Manager: ") + "\n"  
    emplist_employees = ask_employees_info()
    emplist = Employee_list(emplist_title, emplist_description, emplist_manager, emplist_employees)
    print("<<< New employee list created Successfully! >>>")
    return emplist

def add_employee(emplist): # Add a new employee #                                 # Option 2 #                                                            
    print("<<< Please enter new employee information employee >>>")
    new_employee_ID =  input("Please enter new employee ID: ") + "\n" 
    new_employee_name = input("Please enter new employee name: ") + "\n"
    new_employee_age =  input("Please enter new employee age: ") + "\n" 
    new_employee_sex =  input("Please enter new employee sex: ") + "\n" 
    new_employee_address =  input("Please enter new employee address: ") + "\n" 
    new_employee_position = input("Please enter new employee position: ") + "\n"
    new_employee_salary =  input("Please enter new employee salary: ") + "\n" 
    new_employee = Employee_info(new_employee_ID, new_employee_name, new_employee_age, new_employee_sex, new_employee_address, new_employee_position, new_employee_salary)
    emplist.employees.append(new_employee)
    print("<<< Added Successfully! >>>")
    return emplist

def show_emplist(emplist): # Show employee list #                                 # Option 3 #                                                           
    print("Employee's list Title: " + emplist.title, end="")
    print("Employee's list Description: " + emplist.description, end="")
    print("Employee's list Manager: " + emplist.manager, end="\n")     
    print_employees(emplist.employees)

def search_employee(emplist): # Search a specific employee #                      # Option 4 #                               
    print_employees(emplist.employees)
    total = len(emplist.employees)
    choice = select_in_range("Please enter the employee you want to Search (1," + str(total) + "): " , 1, total)
    print("Searched employee: ")
    print_employee(emplist.employees[choice-1])    
    print("<<< Searched Successfully! >>>")
    return emplist

def delete_employee(emplist): # Delete an employee #                              # Option 5 #                                                                                                                 
    print_employees(emplist.employees)
    choice = select_in_range("Please enter the employee you want to Delete: ",1,len(emplist.employees))
    new_employee_list = []
    for i in range(len(emplist.employees)):
        if i == choice-1:
            continue
        new_employee_list.append(emplist.employees[i])

    emplist.employees = new_employee_list

    print("<<< Deleted Successfully! >>>")
    return emplist

def update_emplist(emplist): # Update employee list's information #               # Option 6 #                                                                                                          
    print("Which information you would like to change?")
    print("1. Employee's list Title.")    
    print("2. Employee's list Description.") 
    print("3. Employee's list Manager.")        

    choice = select_in_range("Please choose an option you want to Update (1-3):", 1, 3)
    if choice == 1:
        new_emplist_title = input("Enter new Title for employee list: ") + "\n"
        emplist.title = new_emplist_title
        print("<<< Updated Successfully! >>>")
        return emplist
    if choice == 2:
        new_emplist_description = input("Enter new Description for employee list: ") + "\n"
        emplist.description = new_emplist_description
        print("<<< Updated Successfully! >>>")
        return emplist
    if choice == 3:
        new_emplist_manager = input("Enter new Manager for employee list: ") + "\n"
        emplist.manager = new_emplist_manager
        print("<<< Updated Successfully! >>>")
        return emplist

def write_employee_txt(employee, file): # Write an employee to a text file #                                             
    file.write(employee.ID)
    file.write(employee.name)
    file.write(employee.age)
    file.write(employee.sex)
    file.write(employee.address)
    file.write(employee.position)
    file.write(employee.salary)

def read_employee_from_txt(file): # Read an employee from a text file #                                                   
    ID = file.readline()
    name = file.readline()
    age = file.readline()
    sex = file.readline()
    address = file.readline()
    position = file.readline()
    salary = file.readline()
    employee = Employee_info(ID, name, age, sex, address, position, salary) 
    return employee

def write_employees_txt(employees, file): # Write employees to a text file #                                             
    total = len(employees)
    file.write(str(total) + "\n")
    for i in range(total):
        write_employee_txt(employees[i], file)

def read_employees_from_txt(file): # Read employees from a text file #                                                     
    employees = []
    total = file.readline()     
    for i in range(int(total)):
        employee = read_employee_from_txt(file)
        employees.append(employee)
    return employees

def read_emplist_from_txt(): # Read employee list from a text file #                                                        
    with open("emp_data.txt", "r") as file:
        emplist_title = file.readline()
        emplist_description = file.readline()
        emplist_manager = file.readline()        
        emplist_employees = read_employees_from_txt(file)
    emplist = Employee_list(emplist_title, emplist_description, emplist_manager, emplist_employees)
    return emplist

def save_emplist(emplist): # Save and Exit #                                      # Option 7 #                                                     
    with open("emp_data.txt", "w") as file:
        file.write(emplist.title)
        file.write(emplist.description)
        file.write(emplist.manager)        
        write_employees_txt(emplist.employees, file)
    print("<<< Successfully saved employee list to a text file! >>>")

def show_menu(): # Menu #                                                                         
    print("Employee management Menu:")
    print("---------------------------------------------------")
    print("| Option 1: Create a new employee list.           |")
    print("| Option 2: Add a new employee.                   |")
    print("| Option 3: Show employee list.                   |")
    print("| Option 4: Search a specific employee.           |")
    print("| Option 5: Delete a specific employee.           |")
    print("| Option 6: Update employee list's information.   |")    
    print("| Option 7: Save and Exit.                        |")
    print("---------------------------------------------------")

def main(): # Main() #                                                                                          
    try:
        emplist = read_emplist_from_txt()
        print("<<< Loaded data successfully! >>>")
    except:
        print("Welcome to Group 16's project!")     

    while True:
        show_menu()
        choice = select_in_range("Please select an option (1-7).", 1, 7)
        if choice == 1: # Create #             
            print("<<< You chose Option 1! >>>")
            emplist = create_emp_list()
            input("\nPress Enter to continue.\n") 
        elif choice == 2: # Add #
            print("<<< You chose Option 2! >>>")
            emplist = add_employee(emplist)
            input("\nPress Enter to continue.\n")
        elif choice == 3: # Show #
            print("<<< You chose Option 3! >>>")
            show_emplist(emplist)
            input("\nPress Enter to continue.\n")
        elif choice == 4: # Search #             
            print("<<< You chose Option 4! >>>")
            search_employee(emplist)
            input("\nPress Enter to continue.\n")
        elif choice == 5: # Delete #             
            print("<<< You chose Option 5! >>>")
            emplist = delete_employee(emplist)
            input("\nPress Enter to continue.\n")
        elif choice == 6: # Update #             
            print("<<< You chose Option 6! >>>")
            emplist = update_emplist(emplist)
            input("\nPress Enter to continue.\n")
        elif choice == 7: # Save and exit #
            print("<<< You chose Option 7! >>>")
            save_emplist(emplist)
            input("\nPress Enter to continue.\n")
            break
        else:
            print("Wrong Input, Exist.")
            break
            

main()